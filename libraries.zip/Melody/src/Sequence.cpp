#include "Sequence.h"

Sequence::Sequence() {}
Sequence:: ~Sequence() {}